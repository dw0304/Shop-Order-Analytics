import io
import re
from typing import Optional

import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st
from openpyxl import load_workbook

st.set_page_config(page_title="TikTok Shop Order Analytics v2", page_icon="📊", layout="wide")

# Core fields required for the v2 calculations. TikTok can vary optional columns
# between export versions, so optional fields are filled with blanks when absent.
REQUIRED_COLUMNS = [
    "Order ID", "Order Status", "Cancelation/Return Type", "Seller SKU",
    "Product Name", "Variation", "Quantity", "Sku Quantity of return",
    "SKU Subtotal After Discount", "Tracking ID", "Created Time",
]
OPTIONAL_COLUMNS = [
    "Order Refund Amount", "Cancelled Time", "Cancel By", "Cancel Reason",
    "Order Channel", "Creator Handle",
]

# TikTok has used slightly different spellings across export versions.
COLUMN_ALIASES = {
    "Cancellation/Return Type": "Cancelation/Return Type",
    "Cancellation / Return Type": "Cancelation/Return Type",
    "Cancelation / Return Type": "Cancelation/Return Type",
    "SKU Quantity of Return": "Sku Quantity of return",
    "SKU Quantity Of Return": "Sku Quantity of return",
    "Sku Quantity of Return": "Sku Quantity of return",
    "SKU Subtotal after Discount": "SKU Subtotal After Discount",
    "SKU Subtotal After discount": "SKU Subtotal After Discount",
}

def _norm_header(value: object) -> str:
    text = str(value).replace("\ufeff", "").replace("\xa0", " ").strip()
    text = re.sub(r"\s+", " ", text)
    return text

def _canonicalize_columns(columns) -> list[str]:
    out = []
    seen = {}
    for raw in columns:
        name = _norm_header(raw)
        name = COLUMN_ALIASES.get(name, name)
        # Avoid silently creating duplicate column names.
        if name in seen:
            seen[name] += 1
            name = f"{name}__{seen[name]}"
        else:
            seen[name] = 1
        out.append(name)
    return out


STATUS_LABELS = {
    "Completed": "Successful / Completed",
    "Shipped": "Shipped",
    "To ship": "To Ship",
    "Cancelled": "Cancelled",
}


def parse_money(x) -> float:
    if pd.isna(x) or x == "":
        return 0.0
    s = str(x).strip()
    s = re.sub(r"[^0-9,.-]", "", s)
    if not s:
        return 0.0
    # TikTok exports may use European decimal formatting.
    if "," in s and "." in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        parts = s.split(",")
        if len(parts[-1]) <= 2:
            s = "".join(parts[:-1]).replace(".", "") + "." + parts[-1]
        else:
            s = s.replace(",", "")
    try:
        return float(s)
    except ValueError:
        return 0.0


def normalize_money_series(s: pd.Series) -> pd.Series:
    return s.map(parse_money).astype(float)


def clean_uploaded_excel(file_bytes: bytes) -> pd.DataFrame:
    """Read TikTok All Order exports robustly across minor export-format changes."""
    # IMPORTANT: TikTok All Order XLSX files can contain cell types/metadata that
    # make pandas.read_excel return only the first column. openpyxl reads the
    # workbook faithfully, so use it as the source of truth.
    wb = load_workbook(io.BytesIO(file_bytes), read_only=False, data_only=True)
    sheet = "OrderSKUList" if "OrderSKUList" in wb.sheetnames else wb.sheetnames[0]
    ws = wb[sheet]
    raw_rows = list(ws.iter_rows(values_only=True))
    if not raw_rows:
        raise ValueError(f"The sheet '{sheet}' is empty.")

    # Scan the first 12 rows to find the real header.
    header_row = None
    best_score = -1
    for i, row in enumerate(raw_rows[:12]):
        cols = _canonicalize_columns(row)
        score = sum(c in cols for c in REQUIRED_COLUMNS)
        if "Order ID" in cols and score > best_score:
            best_score = score
            header_row = i
    if header_row is None:
        raise ValueError(
            f"Could not detect the TikTok header row in sheet '{sheet}'. "
            f"Expected a row containing fields such as Order ID, Seller SKU and SKU Subtotal After Discount."
        )

    headers = _canonicalize_columns(raw_rows[header_row])
    width = len(headers)
    body = [list(r[:width]) for r in raw_rows[header_row + 1:]]
    df = pd.DataFrame(body, columns=headers)

    # Add optional fields when a newer/older export does not provide them.
    for c in OPTIONAL_COLUMNS:
        if c not in df.columns:
            df[c] = ""

    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        available = ", ".join(map(str, df.columns.tolist()))
        raise ValueError(
            "Missing required columns: " + ", ".join(missing) +
            f". Detected header row: {header_row + 1}. Available columns: {available}"
        )

    # TikTok exports include a descriptive row immediately after the header.
    order_id_text = df["Order ID"].astype(str).str.strip()
    df = df.loc[~order_id_text.eq("Platform unique order ID.")].copy()
    # Also drop completely empty rows.
    df = df.loc[~df["Order ID"].isna() & ~df["Order ID"].astype(str).str.strip().eq("")].copy()

    # Keep every SKU line as one record: DO NOT deduplicate Order ID.
    for c in ["Quantity", "Sku Quantity of return"]:
        df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0)
    df["SKU Subtotal After Discount_num"] = normalize_money_series(df["SKU Subtotal After Discount"])
    df["Order Refund Amount_num"] = normalize_money_series(df["Order Refund Amount"])
    df["Created_dt"] = pd.to_datetime(df["Created Time"], errors="coerce")
    if df["Created_dt"].isna().all():
        df["Created_dt"] = pd.to_datetime(
            df["Created Time"].astype(str), errors="coerce", utc=True
        ).dt.tz_localize(None)
    df["Date"] = df["Created_dt"].dt.date

    df["CancelType"] = df["Cancelation/Return Type"].astype(str).str.strip()
    df.loc[df["CancelType"].eq("nan"), "CancelType"] = ""
    # Treat None/NaN/blank as no tracking.  TikTok exports often represent
    # empty cells as Python None when read with openpyxl, so simply casting
    # to string would incorrectly turn them into the literal "None".
    tracking = df["Tracking ID"].astype("string").fillna("").str.strip()
    df["Tracking_present"] = tracking.ne("")
    df["Is_Cancel"] = df["CancelType"].str.casefold().eq("cancel")
    df["Is_ReturnRefund"] = df["CancelType"].str.casefold().eq("return/refund")
    # Business rule: Return/Refund is Refund. Cancel + Tracking is a separate
    # operational bucket and is NOT a Refund.
    df["Is_Refund"] = df["Is_ReturnRefund"]
    df["Is_Tracked_Cancel"] = df["Is_Cancel"] & df["Tracking_present"]
    df["Is_Cancel_NonRefund"] = df["Is_Cancel"] & ~df["Tracking_present"]
    status_clean = df["Order Status"].astype(str).str.strip()
    df["Status_Clean"] = status_clean.map(STATUS_LABELS).fillna(status_clean)

    # Mutually-exclusive business outcome. Each SKU record belongs to exactly
    # one outcome so the outcome chart always sums to the total record count.
    # Priority: actual Return/Refund > Cancel + Tracking > Cancel > raw status.
    df["Business Outcome"] = np.select(
        [
            df["Is_ReturnRefund"],
            df["Is_Tracked_Cancel"],
            df["Is_Cancel_NonRefund"],
            status_clean.eq("Completed"),
            status_clean.eq("Shipped"),
            status_clean.eq("To ship"),
        ],
        [
            "Return/Refund",
            "Cancel + Tracking",
            "Cancel",
            "Successful",
            "Shipped",
            "To Ship",
        ],
        default="Other",
    )
    df["Is_Success"] = df["Business Outcome"].eq("Successful")
    df["Is_Tracked_Cancel"] = df["Business Outcome"].eq("Cancel + Tracking")
    df["Is_Cancel_NonRefund"] = df["Business Outcome"].eq("Cancel")
    return df.reset_index(drop=True)


def fmt_eur(x: float) -> str:
    return f"€{x:,.2f}"


def product_summary(df: pd.DataFrame) -> pd.DataFrame:
    g = df.groupby(["Seller SKU", "Product Name"], dropna=False).agg(
        Records=("Order ID", "size"),
        Qty=("Quantity", "sum"),
        GMV=("SKU Subtotal After Discount_num", "sum"),
        Refund_Records=("Is_Refund", "sum"),
        Cancel_Records=("Is_Cancel", "sum"),
        Refund_GMV=("SKU Subtotal After Discount_num", lambda s: s[df.loc[s.index, "Is_Refund"]].sum()),
        Cancel_GMV=("SKU Subtotal After Discount_num", lambda s: s[df.loc[s.index, "Is_Cancel"]].sum()),
    ).reset_index()
    g["Refund Rate"] = np.where(g["Records"] > 0, g["Refund_Records"] / g["Records"], 0)
    g["Cancel Rate"] = np.where(g["Records"] > 0, g["Cancel_Records"] / g["Records"], 0)
    g["Net GMV"] = g["GMV"] - g["Refund_GMV"] - g["Cancel_GMV"]
    g["Health"] = np.select(
        [
            (g["Records"] >= 10) & (g["Refund Rate"] < 0.10) & (g["Cancel Rate"] < 0.15),
            (g["Records"] >= 10) & ((g["Refund Rate"] >= 0.20) | (g["Cancel Rate"] >= 0.30)),
            g["Records"] < 10,
        ],
        ["Winner", "Problematic", "Low Volume"],
        default="Monitor",
    )
    return g


def kpis(df: pd.DataFrame) -> dict:
    total = len(df)
    outcome = df["Business Outcome"]
    refund = int((outcome == "Return/Refund").sum())
    tracked_cancel = int((outcome == "Cancel + Tracking").sum())
    cancel = int(outcome.isin(["Cancel", "Cancel + Tracking"]).sum())
    refund_gmv = df.loc[outcome == "Return/Refund", "SKU Subtotal After Discount_num"].sum()
    tracked_cancel_gmv = df.loc[outcome == "Cancel + Tracking", "SKU Subtotal After Discount_num"].sum()
    cancel_gmv = df.loc[outcome == "Cancel", "SKU Subtotal After Discount_num"].sum()
    gmv = df["SKU Subtotal After Discount_num"].sum()
    return {
        "records": total,
        "successful": int((outcome == "Successful").sum()),
        "shipped": int((outcome == "Shipped").sum()),
        "to_ship": int((outcome == "To Ship").sum()),
        "cancel": cancel,
        "cancel_nontracked": int((outcome == "Cancel").sum()),
        "return_refund": refund,
        "cancel_tracking": tracked_cancel,
        "refund": refund,
        "gmv": gmv,
        "refund_gmv": refund_gmv,
        "tracked_cancel_gmv": tracked_cancel_gmv,
        "cancel_gmv": cancel_gmv,
        "net_gmv": gmv - refund_gmv - tracked_cancel_gmv - cancel_gmv,
        "refund_rate": refund / total if total else 0,
        "cancel_rate": cancel / total if total else 0,
        "tracked_cancel_rate": tracked_cancel / total if total else 0,
    }


def main():
    st.title("📊 TikTok Shop Order Analytics — Dashboard v2")
    st.caption("SKU-line based analytics • TikTok All Order export")

    with st.sidebar:
        st.header("Upload")
        uploaded = st.file_uploader("All Order Excel", type=["xlsx", "xls"])
        st.divider()
        st.markdown("**Business rules**")
        st.markdown("- 1 SKU row = 1 order record\n- Refund = Return/Refund\n- Tracked Cancel = Cancel + Tracking\n- GMV = SUM(SKU Subtotal After Discount)\n- Cancel without tracking = Cancel\n- No Order ID deduplication")

    if not uploaded:
        st.info("Upload a TikTok Shop All Order export to start.")
        return

    try:
        df = clean_uploaded_excel(uploaded.getvalue())
    except Exception as e:
        st.error(f"Could not read the file: {e}")
        return

    st.success(f"Loaded {len(df):,} SKU-order records.")
    with st.expander("ℹ️ File detection", expanded=False):
        st.write("Header detection and column normalization succeeded. TikTok metadata rows are ignored automatically.")

    # Filters
    with st.expander("🔎 Filters", expanded=True):
        c1, c2, c3, c4 = st.columns(4)
        products = sorted([x for x in df["Product Name"].dropna().astype(str).unique() if x and x != "nan"])
        skus = sorted([x for x in df["Seller SKU"].dropna().astype(str).unique() if x and x != "nan"])
        status_opts = sorted(df["Status_Clean"].dropna().astype(str).unique())
        date_min = df["Date"].dropna().min()
        date_max = df["Date"].dropna().max()

        selected_products = c1.multiselect("Product", products)
        selected_skus = c2.multiselect("SKU", skus)
        selected_status = c3.multiselect("Order Status", status_opts)
        if pd.notna(date_min) and pd.notna(date_max):
            selected_dates = c4.date_input("Created date", value=(date_min, date_max))
        else:
            selected_dates = None

    f = df.copy()
    if selected_products:
        f = f[f["Product Name"].astype(str).isin(selected_products)]
    if selected_skus:
        f = f[f["Seller SKU"].astype(str).isin(selected_skus)]
    if selected_status:
        f = f[f["Status_Clean"].isin(selected_status)]
    if isinstance(selected_dates, tuple) and len(selected_dates) == 2:
        f = f[(f["Date"] >= selected_dates[0]) & (f["Date"] <= selected_dates[1])]

    m = kpis(f)
    a,b,c,d = st.columns(4)
    a.metric("Order Records", f"{m['records']:,}")
    b.metric("Gross GMV", fmt_eur(m['gmv']))
    c.metric("Net GMV", fmt_eur(m['net_gmv']))
    d.metric("Refund Rate", f"{m['refund_rate']:.2%}")

    a,b,c,d,e,fcol = st.columns(6)
    a.metric("Successful", f"{m['successful']:,}")
    b.metric("Shipped", f"{m['shipped']:,}")
    c.metric("To Ship", f"{m['to_ship']:,}")
    d.metric("Cancel", f"{m['cancel']:,}")
    e.metric("Return/Refund", f"{m['refund']:,}")
    fcol.metric("Cancel Rate", f"{m['cancel_rate']:.2%}")

    st.divider()
    st.subheader("Order & Money Overview")
    ch1, ch2 = st.columns(2)
    outcome_order = ["Successful", "Shipped", "To Ship", "Cancel", "Cancel + Tracking", "Return/Refund", "Other"]
    counts = f["Business Outcome"].value_counts()
    status_counts = pd.DataFrame({"Outcome": outcome_order, "Records": [int(counts.get(x, 0)) for x in outcome_order]})
    ch1.plotly_chart(px.bar(status_counts, x="Outcome", y="Records", text="Records", title="Order Records by Outcome"), use_container_width=True)
    money = pd.DataFrame({"Category": ["Gross GMV", "Return/Refund GMV", "Cancel + Tracking GMV", "Cancel GMV", "Net GMV"],
                          "EUR": [m['gmv'], m['refund_gmv'], m['tracked_cancel_gmv'], m['cancel_gmv'], m['net_gmv']]})
    ch2.plotly_chart(px.bar(money, x="Category", y="EUR", text="EUR", title="GMV Breakdown"), use_container_width=True)

    if not f.empty and f["Date"].notna().any():
        daily = f.groupby("Date").agg(
            Records=("Order ID", "size"),
            GMV=("SKU Subtotal After Discount_num", "sum"),
            Refund=("Is_Refund", "sum"),
            Cancel=("Business Outcome", lambda s: (s == "Cancel").sum()),
        Tracked_Cancel=("Business Outcome", lambda s: (s == "Cancel + Tracking").sum()),
        ).reset_index()
        st.subheader("Daily Trend")
        daily_fig = px.bar(daily, x="Date", y="Records", title="Daily Order Records")
        st.plotly_chart(daily_fig, use_container_width=True)
        daily_money = px.bar(daily, x="Date", y="GMV", title="Daily GMV")
        st.plotly_chart(daily_money, use_container_width=True)

    st.divider()
    st.subheader("🔥 Product / SKU Analytics")
    ps = product_summary(f)
    tab1, tab2, tab3, tab4 = st.tabs(["Top Sellers", "High Refund", "GMV", "Health Matrix"])
    with tab1:
        top = ps.sort_values(["Records", "Qty"], ascending=False).head(25)
        st.dataframe(top[["Seller SKU","Product Name","Records","Qty","GMV","Refund Rate","Cancel Rate","Health"]], use_container_width=True, hide_index=True)
    with tab2:
        high = ps[ps["Records"] >= 3].sort_values("Refund Rate", ascending=False).head(25).copy()
        high["Refund Rate"] = high["Refund Rate"].map(lambda x: f"{x:.2%}")
        st.dataframe(high[["Seller SKU","Product Name","Records","Refund_Records","Refund Rate","Refund_GMV"]], use_container_width=True, hide_index=True)
    with tab3:
        topgmv = ps.sort_values("GMV", ascending=False).head(25)
        st.dataframe(topgmv[["Seller SKU","Product Name","Records","Qty","GMV","Net GMV","Refund_GMV"]], use_container_width=True, hide_index=True)
    with tab4:
        matrix = ps.copy()
        fig = px.scatter(matrix, x="Records", y="Refund Rate", size="GMV", color="Health",
                         hover_data=["Seller SKU", "Product Name", "Qty", "Net GMV"],
                         title="SKU Performance Matrix — Sales vs Refund Rate")
        st.plotly_chart(fig, use_container_width=True)

    st.divider()
    st.subheader("📋 Refund / Cancel Detail")
    detail_cols = ["Order ID","Order Status","Cancelation/Return Type","Seller SKU","Product Name","Variation","Quantity",
                   "SKU Subtotal After Discount","Order Refund Amount","Tracking ID","Cancel By","Cancel Reason"]
    detail = f[f["Is_Refund"] | f["Is_Cancel"]][detail_cols].copy()
    st.dataframe(detail, use_container_width=True, hide_index=True)

    st.caption("Rule: Return/Refund = Refund. Cancel + Tracking is shown separately as an operational bucket, not as Refund. System/Seller/Buyer is not inferred without a reliable source field.")


if __name__ == "__main__":
    main()
